/*
** $Id: ralloc.h,v 1.6 2008-12-27 01:03:17 thor Exp $
**
*/

#ifndef JPEGXR_RALLOC_H
#define JPEGXR_RALLOC_H

//#define USE_RALLOC

extern size_t test_quant(hdp_image_t image, int tx, int ty, int mx, int my,int qu,double *dist,int preshift,int dry_run);

#endif
